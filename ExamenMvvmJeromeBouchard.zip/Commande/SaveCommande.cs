﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using ExamenMvvm.ViewModel;

namespace ExamenMvvm.Commande
{
    class SaveCommande : ICommand
    {
        public SaveCommande(MainViewModel viewModel)
        {
            _viewModel = viewModel;
        }

        private MainViewModel _viewModel;

        #region ICommand Members

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public bool CanExecute(object parameter)
        {
            return _viewModel.CanUpdate;
        }

        public void Execute(object parameter)
        {
            _viewModel.SaveChanges(this);
        }

        #endregion
    }
}
