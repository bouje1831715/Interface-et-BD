﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenMvvm.Model
{
    class Personne : INotifyPropertyChanged
    {
        public Personne(string _nom, string _prenom, string _adresseCourriel)
        {
            nom = _nom;
            prenom = _prenom;
            adresseCourriel = _adresseCourriel;
        }

        private string _nom;

        public string nom
        {
            get
            {
                return _nom;
            }
            set
            {
                _nom = value;
                OnPropertyChanged("nom");
            }
        }

        private string _prenom;

        public string prenom
        {
            get
            {
                return _prenom;
            }
            set
            {
                _prenom = value;
                OnPropertyChanged("prenom");
            }
        }

        private string _adresseCourriel;

        public string adresseCourriel
        {
            get
            {
                return _adresseCourriel;
            }
            set
            {
                _adresseCourriel = value;
                OnPropertyChanged("adresseCourriel");
            }
        }



        #region INotifyPropertyChanged Members
        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        #endregion
    }
}
