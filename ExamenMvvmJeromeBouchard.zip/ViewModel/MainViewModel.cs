﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using ExamenMvvm.Model;
using ExamenMvvm.Commande;
using System.Windows;

namespace ExamenMvvm.ViewModel
{
    class MainViewModel
    {
        public MainViewModel()
        {
            _personne = new Personne("Doe", "John", "jdoe@hotmail.com");
            SaveCommande = new SaveCommande(this);
            HelpCommande = new HelpCommande(this);
            ResetCommande = new ResetCommande(this);
        }

        public bool CanUpdate
        {
            get
            {
                if (personne == null)
                {
                    return false;
                }
                return true;
            }
        }

        private Personne _personne;
        public Personne personne
        {
            get
            {
                return _personne;
            }
        }

        public ICommand HelpCommande
        {
            get;
            private set;
        }
        public ICommand ResetCommande
        {
            get;
            private set;
        }
        public ICommand SaveCommande
        {
            get;
            private set;
        }

        public void SaveChanges(object commande)
        {
            if(commande == HelpCommande)
            {
                if (personne.prenom == "")
                {
                    personne.prenom = "A REMPLIR";
                }
                if (personne.nom == "")
                {
                    personne.nom = "A REMPLIR";
                }
                if (personne.adresseCourriel == "")
                {
                    personne.adresseCourriel = "A REMPLIR";
                }
                MessageBox.Show("Les champs a remplir ont été indiquer");
            }
            else if(commande == ResetCommande)
            {
                personne.prenom = "";
                personne.nom = "";
                personne.adresseCourriel = "";
                MessageBox.Show("Réinitialisation éffectuer avec succes");
            }
            else if (commande == SaveCommande)
            {
                MessageBox.Show("La sauvegarde a été réussi");
            }
            else
            {
                Debug.Assert(false, String.Format("Bruh ur dumb"));
            }
        }
    }
}
