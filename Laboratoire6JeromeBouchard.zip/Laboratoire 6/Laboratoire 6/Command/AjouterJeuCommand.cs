﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Laboratoire_6.Viewmodel;

namespace Laboratoire_6.Command
{
    class AjouterJeuCommand : ICommand
    {
        public AjouterJeuCommand(JeuViewModel viewModel)
        {
            _viewModel = viewModel;
        }

        private JeuViewModel _viewModel;

        #region ICommand Members

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public bool CanExecute(object parameter)
        {
            return _viewModel.CanUpdate;
        }

        public void Execute(object parameter)
        {
            _viewModel.AjouterJeu();
        }

        #endregion
    }
}
