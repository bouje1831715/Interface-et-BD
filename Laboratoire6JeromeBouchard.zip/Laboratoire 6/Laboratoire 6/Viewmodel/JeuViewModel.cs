﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Laboratoire_6.Command;
using Laboratoire_6.Model;
using Laboratoire_6.View;

namespace Laboratoire_6.Viewmodel
{
    class JeuViewModel : INotifyPropertyChanged
    {
        public JeuViewModel()

        {
            AjouterJeuCommand = new AjouterJeuCommand(this);

        }
        public ICommand AjouterJeuCommand
        {
            get;
            private set;
        }


        private string connectionString;

        #region Jeu Nom

        private string _nom;

        public string nom
        {
            get { return this._nom; }
            set
            {
                if (value != _nom)
                {
                    _nom = value;
                    OnPropertyChanged("nom");
                }
            }
        }

        #endregion

        #region Jeu Emplacement

        private string _Emplacement;

        public string Emplacement
        {
            get { return this._Emplacement; }
            set
            {
                if (value != _Emplacement)
                {
                    _Emplacement = value;
                    OnPropertyChanged("Emplacement");
                }
            }
        }

        #endregion

        public bool CanUpdate
        {
            get
            {
                return true;
            }
        }

        #region Commande AjouterJeu
        public void AjouterJeu()
        {
            try
            {
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO tblJeu (nom, emplacement) VALUES (@param1, @param2)", con);
                cmd.Parameters.Add("@param1", System.Data.SqlDbType.VarChar, 255).Value = Nom;
                cmd.Parameters.Add("@param2", System.Data.SqlDbType.VarChar, 255).Value = Emplacement;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {

                throw;
            }


        }

        #endregion





        #region OnPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }


        #endregion
    }
}
