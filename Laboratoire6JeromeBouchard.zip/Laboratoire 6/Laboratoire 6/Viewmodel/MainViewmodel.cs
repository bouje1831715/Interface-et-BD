﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Laboratoire_6.View;
using Laboratoire_6.Model;
using System.Windows;
using Laboratoire_6.Command;
using System.Data.SqlClient;

namespace Laboratoire_6.Viewmodel
{
    class MainViewmodel : INotifyPropertyChanged
    {

        public MainViewmodel()

        {
            InscriptionCommand = new InscriptionCommand(this);
            ConnexionCommand = new ConnexionCommand(this);
        }
        public ICommand InscriptionCommand
        {
            get;
            private set;
        }


        private string connectionString;

        #region Inscription Prenom

        private string _IPrenom;

        public string Iprenom
        {
            get { return this._IPrenom; }
            set
            {
                if (value != _IPrenom)
                {
                    _IPrenom = value;
                    OnPropertyChanged("IPrenom");
                }
            }
        }

        #endregion

        #region Inscription Nom

        private string _INom;

        public string INom
        {
            get { return this._INom; }
            set
            {
                if (value != _INom)
                {
                    _INom = value;
                    OnPropertyChanged("INom");
                }
            }
        }

        #endregion

        #region Inscription Courriel

        private string _ICourriel;

        public string ICourriel
        {
            get { return this._ICourriel; }
            set
            {
                if (value != _ICourriel)
                {
                    _ICourriel = value;
                    OnPropertyChanged("ICourriel");
                }
            }
        }

        #endregion

        #region Inscription Mdp

        private string _IMdp;

        public string IMdp
        {
            get { return this._IMdp; }
            set
            {
                if (value != _IMdp)
                {
                    _IMdp = value;
                    OnPropertyChanged("IMdp");
                }
            }
        }

        #endregion

        #region Connexion Courriel

        private string _CCourriel;

        public string CCouriel
        {
            get { return this._CCourriel; }
            set
            {
                if (value != _CCourriel)
                {
                    _CCourriel = value;
                    OnPropertyChanged("CCouriel");
                }
            }
        }

        #endregion

        #region Connexion Mdp

        private string _CMdp;

        public string CMdp
        {
            get { return this._CMdp; }
            set
            {
                if (value != _CMdp)
                {
                    _CMdp = value;
                    OnPropertyChanged("CMdp");
                }
            }
        }

        #endregion



        public bool CanUpdate
        {
            get
            {
                return true;
            }
        }

        #region Commande Inscription
        public void Inscription()
        {
            try
            {
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO tblJoueur (nom, prenom, courriel, motDePasse) VALUES (@param1, @param2, @param3 , @param4)", con);
                cmd.Parameters.Add("@param1", System.Data.SqlDbType.VarChar, 255).Value = Iprenom;
                cmd.Parameters.Add("@param2", System.Data.SqlDbType.VarChar, 255).Value = INom;
                cmd.Parameters.Add("@param3", System.Data.SqlDbType.VarChar, 255).Value = ICourriel;
                cmd.Parameters.Add("@param4", System.Data.SqlDbType.VarChar, 255).Value = IMdp;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {

                throw;
            }


        }
        
        #endregion

        public void Connexion()
        {
            try
            {
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT courriel, motDePasse FROM tblJoueur", con);
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.ExecuteNonQuery();

            }
            catch (Exception e)
            {

                throw;
            }
        }





        #region OnPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }


        #endregion
    }
}
