USE BD_LaboratoireMvvm_JeromeBouchard;

ALTER TABLE tblJoueur
ADD CONSTRAINT PK_idJoueur PRIMARY KEY (idJoueur);

ALTER TABLE tblJeu
ADD CONSTRAINT PK_idJeu PRIMARY KEY (idJeu),
CONSTRAINT FK_idPlayer FOREIGN KEY (idPlayer)REFERENCES tblJoueur(idJoueur);

USE master;