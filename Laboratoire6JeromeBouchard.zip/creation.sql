DROP DATABASE BD_LaboratoireMvvm_JeromeBouchard;

CREATE DATABASE BD_LaboratoireMvvm_JeromeBouchard;

USE BD_LaboratoireMvvm_JeromeBouchard;

CREATE TABLE tblJoueur(

	idJoueur int IDENTITY(1, 1) NOT NULL,
	nom varchar NOT NULL,
	prenom varchar NOT NULL,
	courriel varchar NOT NULL,
	motDePasse varchar NOT NULL
);

CREATE TABLE tblJeu(

	idJeu int IDENTITY(1, 1) NOT NULL,
	nom varchar NOT NULL,
	emplacement varchar NOT NULL,
	idPlayer int NOT NULL
);

USE master;