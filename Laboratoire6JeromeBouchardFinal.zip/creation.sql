DROP DATABASE BD_LaboratoireMvvm_JeromeBouchard;

CREATE DATABASE BD_LaboratoireMvvm_JeromeBouchard;

USE BD_LaboratoireMvvm_JeromeBouchard;

CREATE TABLE tblJoueur(

	idJoueur int IDENTITY(1, 1) NOT NULL,
	nom varchar(50) NOT NULL,
	prenom varchar(50) NOT NULL,
	courriel varchar(50) NOT NULL,
	motDePasse varchar(50) NOT NULL
);

CREATE TABLE tblJeu(

	idJeu int IDENTITY(1, 1) NOT NULL,
	nom varchar(50) NOT NULL,
	emplacement varchar(50) NOT NULL,
	idPlayer int NOT NULL
);

USE master;